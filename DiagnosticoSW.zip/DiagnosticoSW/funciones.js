// Conteo de Caracteres
function contarCaracteres(cadena) {
    return cadena.length;
}

// Reversión de Cadena
function revertirCadena(frase) {
    return frase.split(' ').reverse().join(' ');
}

// Palíndromo
function esPalindromo(palabra) {
    let palabraInvertida = palabra.split('').reverse().join('');
    return palabra === palabraInvertida;
}

// Ordenamiento de un Arreglo
function ordenarArreglo(arr) {
    return arr.sort((a, b) => a - b);
}

// Suma de elementos de un arreglo
function sumarElementos(arr) {
    return arr.reduce((acumulador, valorActual) => acumulador + valorActual, 0);
}

// Filtrado de elementos en un arreglo
function filtrarMayoresQue(arr, valor) {
    return arr.filter(num => num > valor);
}

// Concatenación de arreglos
function concatenarArreglos(arr1, arr2) {
    return arr1.concat(arr2);
}

// Búsqueda de elementos en un arreglo
function buscarElemento(arr, nombre) {
    return arr.includes(nombre) ? `${nombre} está en el arreglo.` : `${nombre} no está en el arreglo.`;
}

// Ejemplos de uso:
console.log(contarCaracteres("Hola, mundo!"));
console.log(revertirCadena("Hola mundo desde OpenAI"));
console.log(esPalindromo("radar"));
console.log(ordenarArreglo([3, 1, 4, 1, 5, 9]));
console.log(sumarElementos([1, 2, 3, 4, 5]));
console.log(filtrarMayoresQue([10, 20, 30, 40, 50], 25));
console.log(concatenarArreglos(["Hola", "Mundo"], ["desde", "JavaScript"]));
console.log(buscarElemento(["Ana", "Luis", "Maria"], "Luis"));