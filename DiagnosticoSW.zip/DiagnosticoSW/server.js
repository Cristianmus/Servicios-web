const express = require('express');
const app = express();
const port = 3000;

app.use(express.json());  // Para poder trabajar con JSON en el cuerpo de las solicitudes.

let tareas = [];
let id = 1;

// Crear una nueva tarea
app.post('/tareas', (req, res) => {
    const { descripcion, completada = false } = req.body;
    const nuevaTarea = { id: id++, descripcion, completada, fechaCreacion: new Date() };
    tareas.push(nuevaTarea);
    res.status(201).json(nuevaTarea);
});

// Leer todas las tareas
app.get('/tareas', (req, res) => {
    res.json(tareas);
});

// Leer una tarea específica por su ID
app.get('/tareas/:id', (req, res) => {
    const tarea = tareas.find(t => t.id === parseInt(req.params.id));
    if (!tarea) return res.status(404).send('Tarea no encontrada');
    res.json(tarea);
});

// Actualizar una tarea existente
app.put('/tareas/:id', (req, res) => {
    const tarea = tareas.find(t => t.id === parseInt(req.params.id));
    if (!tarea) return res.status(404).send('Tarea no encontrada');

    const { descripcion, completada } = req.body;
    if (descripcion) tarea.descripcion = descripcion;
    if (completada !== undefined) tarea.completada = completada;

    res.json(tarea);
});

// Eliminar una tarea por su ID
app.delete('/tareas/:id', (req, res) => {
    const tareaIndex = tareas.findIndex(t => t.id === parseInt(req.params.id));
    if (tareaIndex === -1) return res.status(404).send('Tarea no encontrada');

    const tareaEliminada = tareas.splice(tareaIndex, 1);
    res.json(tareaEliminada[0]);
});

// Estadísticas de tareas
app.get('/tareas/estadisticas', (req, res) => {
    const totalTareas = tareas.length;
    const completadas = tareas.filter(t => t.completada).length;
    const pendientes = totalTareas - completadas;
    const tareaReciente = tareas.reduce((reciente, t) => t.fechaCreacion > reciente.fechaCreacion ? t : reciente, tareas[0] || {});
    const tareaAntigua = tareas.reduce((antigua, t) => t.fechaCreacion < antigua.fechaCreacion ? t : antigua, tareas[0] || {});

    res.json({
        totalTareas,
        completadas,
        pendientes,
        tareaReciente,
        tareaAntigua
    });
});

// Manejo de errores para solicitudes no válidas
app.use((req, res, next) => {
    res.status(404).send('Ruta no encontrada');
});

app.listen(port, () => {
    console.log(`Servidor corriendo en http://localhost:${port}`);
});
